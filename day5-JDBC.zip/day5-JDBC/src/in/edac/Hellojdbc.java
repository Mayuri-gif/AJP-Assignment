package in.edac;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * r1.database server::mysql :: schema/table
 * 
 * @author Mayuri
 *
 *Fully Classified Name
 *
 *Hellojdbc
 *in.edac.Hellojdbc
 *by writing com.mysql.jdbc we download driver class
 */

public class Hellojdbc {
	public static void main(String[] args) {
		try {
			// dynamically loading class driver
			// we loaded for translating lan
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/edac";
			String user = "root";
			String password="edac20";
			// open connection
			Connection con= DriverManager.getConnection(url, user, password);
			System.out.println("Horray!!! DB Connection Success");
			
			// close connection
			con.close();
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
