package in.edac;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
/**
 * curd operation
 * @author Mayuri
 *
 */


public class Hellojdbc8 {
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/edac";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD="edac20";
public static void main(String[] args) throws Exception {
		
		Connection con = null;
		
		try {
			Scanner scanner = new Scanner(System.in);
			System.out.println("update userName");
			String USERNAME = scanner.nextLine();
			
			System.out.println("update EMAIL");
			String EMAIL = scanner.nextLine();
			
			System.out.println("WHERE ID =");
			int id = scanner.nextInt();
			
			Class.forName(DB_DRIVER);
			
			// Open Connection
			con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             
			// by writing 3 line we execute query
			// here sql indexing start with 1 so at username we write 1
			// this is mostly use and imp
			String sql = "UPDATE user set USERNAME=?,EMAIL=? where ID=?" ;
			
			//for convert java into sql we write preparedstatement
			PreparedStatement ps =con.prepareStatement(sql);
			ps.setString(1, USERNAME);
			ps.setString(2, EMAIL);
			ps.setInt(3, id);
			ps.executeUpdate();
			
			System.out.println("update Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("finally block executed");
			// Close Connection
			con.close();
		}
		
	}

}