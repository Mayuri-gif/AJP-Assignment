package in.edac;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 * curd operation
 * @author Mayuri
 *
 */


public class Hellojdbc5 {
	public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/edac";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD="edac20";
public static void main(String[] args) throws Exception {
		
		Connection con = null;
		
		try {
			// Dynamic Loading!! the class Driver
			Class.forName(DB_DRIVER);
			
			// Open Connection
			con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             
			// by writing 3 line we execute query
			String sql = "INSERT INTO user(USERNAME,PASSWORD,EMAIL,MOBILE) VALUES('abcde','pqrs','abc@gmail.com','1234567')";
			PreparedStatement ps =con.prepareStatement(sql);
			ps.executeUpdate();
			System.out.println("Insert Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// Close Connection
			con.close();
		}
		
	}

}