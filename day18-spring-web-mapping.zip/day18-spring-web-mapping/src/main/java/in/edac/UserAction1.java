package in.edac;


import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserAction1 {

	@GetMapping("/")
	public List<User> getUsers() {
		List<User> list = new ArrayList<User>();
		
		User user1 = new User(1,"mumbai","123","m@gmail");
		User user2 = new User(2, "mumbai", "!@!#!#!#", "mumbai@gmail.com");
		
		list.add(user1);
		list.add(user2);
		
		return list;
	}
	@GetMapping("/{id}")
	public User getSingleUser(@PathVariable int id) {
		User user = new User(id, "mumbai", "!@!#!#!#", "mumbai@gmail.com");
		return user;
	}
	@PostMapping("/")
	public User createUser(User user) {
		// Create the Object in database.
		return user;
	}
	
	@PutMapping("/{id}")
	public User updateUser(@PathVariable int id, User user) {
		// ...update the record in datbase
		return user;
	}
	
	@DeleteMapping("/{id}")
	public int deleteUser(@PathVariable int id) {
		return id;
	}
}
