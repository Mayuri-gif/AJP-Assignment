package in.edac;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class UserAction {

	@GetMapping("/")
	public String helloWorld() {
		return "helloWorld";
	}
	
	@GetMapping("/1")
	public String helloWorldV1() {
		return "helloWorld V1";
	}
	
	@GetMapping("/2")
	public String helloWorldV2() {
		return "helloWorld V2";
	}
}
