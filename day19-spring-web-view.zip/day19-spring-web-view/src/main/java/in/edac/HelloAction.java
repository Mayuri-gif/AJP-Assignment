package in.edac;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hello")
public class HelloAction {

	@GetMapping("/")
	public String sayHello() {
		//return "/views/hello.jsp";
		return "hello";
	}
	
	@GetMapping("/1")
	public String sayHi() {
		return"hi";
	}
	
	@GetMapping("/2")
	public String hellooo() {
		return "hi";
	}
}