package in.edac;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/sample")
public class SampleAction {
	
	@GetMapping("/home-view")
	public String homeView() {
		return "home";
	}

	@GetMapping("/home-view-v1")
	public ModelAndView homeView1() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		return mv;
	}
	
	@GetMapping("/home-view-v2")
	public ModelAndView homeView2() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		String title = "Hello Mumbai";
		mv.addObject("title", title);
		return mv;
	}
	
	@GetMapping("/home-view-v3")
	public ModelAndView homeView3() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		String title = "Hello Mumbai";
		mv.addObject("title", title);
		
		List<String> cityList = Arrays.asList("Delhi","Kolkata","Mumbai","Chennai");
		mv.addObject("cityList", cityList);
		return mv;
	}
	
	@GetMapping("/home-view-v4")
	public ModelAndView homeView4() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		
		String title = "Hello Mumbai";
		mv.addObject("title", title);
		
		List<String> cityList = Arrays.asList("Delhi","Kolkata","Mumbai","Chennai");
		mv.addObject("cityList", cityList);
		
		List<User> userList = new ArrayList<User>();
		userList.add(new User(1,"virat","12340","viru@gmail.com","123456"));
		userList.add(new User(2,"rohit","12340","rohit@gmail.com","1234567"));
		mv.addObject("userList",userList);
		return mv;
	}
	
	
	@GetMapping("/home-view-v5")
	public ModelAndView homeView5(String q) {
		ModelAndView mv = new ModelAndView("home");
		
		if("1".equals(q)) {
			mv.setViewName("hello");
		}
		
		
		String title = "Hello Mumbai" +q;
		mv.addObject("title", title);
		
		List<String> cityList = Arrays.asList("Delhi","Kolkata","Mumbai","Chennai");
		mv.addObject("cityList", cityList);
		
		List<User> userList = new ArrayList<User>();
		userList.add(new User(1,"virat","12340","viru@gmail.com","123456"));
		userList.add(new User(2,"rohit","12340","rohit@gmail.com","1234567"));
		mv.addObject("userList",userList);
		return mv;
	}
}
