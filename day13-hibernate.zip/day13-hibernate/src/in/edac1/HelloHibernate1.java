package in.edac1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import in.edac.entity.Employee1;
import in.edac.entity.Student1;

public class HelloHibernate1 {

public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void main(String args[]) {
		addStudents();
		addEmployee();
	}
	
	public static void addStudents() {
		
	Session session	= sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
	
	Student1 s1 = new Student1("mayu","m@gmail.com","11111");
	Student1 s2 = new Student1("prisha","p@gmail.com","11112");
	Student1 s3 = new Student1("shri","s@gmail.com","111113");
	Student1 s4 = new Student1("sona","h@gmail.com","111114");
	Student1 s5 = new Student1("shree","j@gmail.com","111115");
	
	
	session.save(s1);
	session.save(s2);
	session.save(s3);
	session.save(s4);
	session.save(s5);
	
	
	
	tx.commit();
	session.close();
		
	}
	
	
	
	public static void addEmployee() {
		
		Session session	= sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		Employee1 e1 = new Employee1("cse","mayu","11111");
		Employee1 e2 = new Employee1("ee","prisha","11112");
		Employee1 e3 = new Employee1("ece","shri","111113");
		Employee1 e4 = new Employee1("me","sona","111114");
		Employee1 e5 = new Employee1("civil","shree","111115");
		
		
		session.save(e1);
		session.save(e2);
		session.save(e3);
		session.save(e4);
		session.save(e5);
		
		
		
		tx.commit();
		session.close();
			
		}
		
		
	
	
}
