package in.edac1;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.edac.entity.Student1;


// HQL is only use for reading query
public class HibernateNativeQueryDemo {
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args) {
		//demo1();
		//demo2();
		demo3();
	}

	public static void demo1() {
		 
	Session session	= sessionFactory.openSession();
	
	String hql = " FROM Student1";
	List<Student1> list = session.createQuery(hql, Student1.class).list();
	
	list.stream().map(Student1::getName).forEach(System.out::println);
	
	session.close();
	}
	
	public static void demo2() {
		 
		Session session	= sessionFactory.openSession();
		
		String hql = "SELECT s FROM Student1 s";
		List<Student1> list = session.createQuery(hql, Student1.class).list();
		
		list.stream().map(Student1::getName).forEach(System.out::println);
		
		session.close();
		}
	
	
	
	public static void demo3() {
		 
		Session session	= sessionFactory.openSession();
		
		String hql = " FROM Student1 s WHERE s.id=:id";
		List<Student1> list = session.createQuery(hql, Student1.class).setParameter("id", 3).list();
		
		list.stream().map(Student1::getName).forEach(System.out::println);
		
		session.close();
		}
	
	
	
}
