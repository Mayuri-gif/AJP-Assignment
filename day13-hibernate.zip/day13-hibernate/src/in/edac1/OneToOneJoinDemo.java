package in.edac1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.edac.entity.Address;
import in.edac.entity.Student2;

public class OneToOneJoinDemo {
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
public static void main(String[] args) {
Session session	= sessionFactory.openSession();

Transaction tx= session.beginTransaction();

Student2 s2 = new Student2("Mayuri","mayu@gmail.com","124567");
Address a1 = new Address("mumbai","mh");


session.save(a1);
session.save(s2);
tx.commit();
session.close();
}
	
	

}
