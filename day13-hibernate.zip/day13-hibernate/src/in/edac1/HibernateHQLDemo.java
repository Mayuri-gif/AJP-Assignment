package in.edac1;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import in.edac.entity.Student1;

public class HibernateHQLDemo {
	public static final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
	
	public static void main(String[] args) {
		//demo1();
		//demo2();
		//demo3();
		//demo4();
		demo5();
		//demo6();
		 //demo7SingleRecord();
	}

	public static void demo1() {
		 
	Session session	= sessionFactory.openSession();
	
	String sql = "SELECT * FROM STUDENTMAYU";
	List<Student1> list = session.createNativeQuery(sql, Student1.class).list();
	
	list.stream().map(Student1::getName).forEach(System.out::println);
	
	session.close();
	}
	
	
	
	public static void demo2() {
		 
		Session session	= sessionFactory.openSession();
		
		String sql = "SELECT * FROM STUDENTMAYU WHERE id=? AND name=?";
		List<Student1> list = session.createNativeQuery(sql, Student1.class)
				.setParameter(1, 3)
				.setParameter(2, "shri")
				.list();
		
		list.stream().map(Student1::getName).forEach(System.out::println);
		
		session.close();
		}
	
	public static void demo3() {
		 
		Session session	= sessionFactory.openSession();
		
		String sql = "SELECT * FROM STUDENTMAYU WHERE id=:id AND name=:name";
		List<Student1> list = session.createNativeQuery(sql, Student1.class)
				.setParameter("id", 4)
				.setParameter("name", "sona")
				.list();
		
		list.stream().map(Student1::getName).forEach(System.out::println);
		
		session.close();
		}
	
	public static void demo4() {
		 
		Session session	= sessionFactory.openSession();
		Transaction tx 	= session.beginTransaction();
		String sql = "INSERT INTO STUDENTMAYU (name,email,mobile) VALUES (:name,:email,:mobile)";
		session.createNativeQuery(sql)
		.setParameter("name","risha")
		.setParameter("email", "ra@gmail.com")
		.setParameter("mobile", "12334567")
		.executeUpdate();
		
		tx.commit();
		session.close();
		}
	
	
	public static void demo5() {
		Session session =  sessionFactory.openSession();
		session.beginTransaction();
		
		String sql = "UPDATE STUDENTMAYU SET name=:name WHERE id=:id";
		session.createNativeQuery(sql)
				.setParameter("name", "riya")
				.setParameter("id", 3)
				.executeUpdate();
		
		session.getTransaction().commit();
		session.close();
	}
	
	
	public static void demo6() {
		Session session =  sessionFactory.openSession();
		session.beginTransaction();
		
		String sql = "DELETE FROM STUDENTMAYU WHERE name=:name ";
		session.createNativeQuery(sql)
				.setParameter("name", "PRISHA")
				
				.executeUpdate();
		
		session.getTransaction().commit();
		session.close();
	}
	
	
	public static void demo7SingleRecord() {
		Session session =  sessionFactory.openSession();
		session.beginTransaction();
		
		String sql = "SELECT * FROM STUDENTMAYU WHERE id=:id ";
		List<Student1> list = session.createNativeQuery(sql,Student1.class)
				.setParameter("id", 1)
				.list();
				Student1 std = list.get(0);
				System.out.println(std);
		session.close();
	}
	
	
	
	public static void demo8SingleRecord() {
		Session session =  sessionFactory.openSession();
		session.beginTransaction();
		
		String sql = "SELECT * FROM STUDENTMAYU WHERE id=:id ";
	Student1 std	= session.createNativeQuery(sql,Student1.class)
				.setParameter("id", 1)
				.getSingleResult();
	System.out.println(std);
		session.close();
	}
}
