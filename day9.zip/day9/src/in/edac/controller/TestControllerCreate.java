package in.edac.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.edac.dao.User;
import in.edac.dao.UserDao;


@WebServlet("/test-controller")
public class TestControllerCreate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String USERNAME = request.getParameter("USERNAME");
			String PASSWORD = request.getParameter("PASSWORD");
			String EMAIL = request.getParameter("EMAIL");
			String MOBILE = request.getParameter("MOBILE");
			UserDao dao = new UserDao();
			User user = new User();
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/edac","root","edac20");
			String sql = "INSERT INTO USERS (USERNAME, EMAIL, PASSWORD, MOBILE) VALUES (?, ?, ?, ?)";
			PreparedStatement ps =  con.prepareStatement(sql);
			ps.setString(1, USERNAME);
			ps.setString(2, EMAIL);
			ps.setString(3, PASSWORD);
			ps.setString(4, MOBILE);
			ps.executeUpdate();
			
			
			request.getRequestDispatcher("success.jsp").forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
		
	}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
		
	}

}
