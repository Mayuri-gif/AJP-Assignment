package in.edac.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.edac.dao.User;
import in.edac.dao.UserDao;


@WebServlet("/test-update")
public class UserControllerUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String USERNAME = request.getParameter("USERNAME");
			String PASSWORD = request.getParameter("PASSWORD");
			String EMAIL = request.getParameter("EMAIL");
			String MOBILE = request.getParameter("MOBILE");
			String idstr = request.getParameter("ID");
			int ID = Integer.parseInt(idstr);
			
			UserDao dao = new UserDao();
			
			User user = new User();
			
			user.setId(ID);
			user.setUsername(USERNAME);
			user.setEmail(PASSWORD);
			user.setPassword(EMAIL);
			user.setMobile(MOBILE);
			
			dao.updateUser(user);
			
			request.getRequestDispatcher("success.jsp").forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
		
	}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
		
	}

}
