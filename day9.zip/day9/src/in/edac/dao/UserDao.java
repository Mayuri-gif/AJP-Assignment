package in.edac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * CRUD
 * createUser
 * @author Mayuri
 *
 */
public class UserDao {
	public static final String DB_DRIVER ="com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/edac";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD ="edac20";
	
	
	// try with resource there is no need of finally below method
	public void checkConnection() {
		try(Connection con 	= DriverManager.getConnection(DB_URL,DB_USER, DB_PASSWORD);
				) {
			Class.forName(DB_DRIVER);
			
		
		
			System.out.println("Success Try with Resourse");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	//by creating object of user in User.java for 100no of para
	public boolean createUser(User user) throws Exception {
		Class.forName(DB_DRIVER);
		try(Connection con	= DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
				) {
			
			
		String sql = "INSERT INTO user(USERNAME, EMAIL, PASSWORD, MOBILE) VALUES (?, ?, ?, ?)";
		 PreparedStatement ps= con.prepareStatement(sql);
		 ps.setString(1,user.getUsername());
		 ps.setString(2,user.getEmail());
		 ps.setString(3,user.getPassword());
		 ps.setString(4,user.getMobile());
		 
		 ps.executeUpdate();
		 System.out.println("Insert Sucess");
		 
		 return true;
		} catch (Exception e) {
			
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean updateUser(User user) {
		try(Connection con 	= DriverManager.getConnection(DB_URL,DB_USER, DB_PASSWORD);
				) {
			Class.forName(DB_DRIVER);
			
		String sql = "UPDATE User SET USERNAME=?, MOBILE=?, PASSWORD=? WHERE ID=?";
		
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getMobile());
			ps.setString(3, user.getPassword());
			ps.setInt(4, user.getId());
			ps.executeUpdate();
			
			return true;
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	}
	
	
	
	public boolean deleteUser(User user) throws Exception {
		Class.forName(DB_DRIVER);
		try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
				){
			String sql = "DELETE FROM User WHERE ID = ? ";
			PreparedStatement ps = con.prepareStatement(sql);
			// here index of id=1
			ps.setInt(1, user.getId());
			ps.executeUpdate();
			
			return true;
			
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	}
	public static void main(String[] args) throws Exception {
		UserDao dao = new UserDao();
		
		//check connection 
		//dao.checkConnectionOld();
		//dao.checkConnection();
		//dao.createUserV1();
		//dao.createUserV2("abcd", "abc@gmail.com", "abc123", "123344566");
		
		//User user = new User("Mumbai","a1@gmail.com","12345","9887766545");
		//dao.createUser(user);
		
		//update user
		//User user = new User("hii","hi@gmail.com","12345","9887766545");
		//user.setId(6);
		//dao.updateUser(user);
		
		//delete useer
		User user = new User();
		user.setId(2);
		dao.deleteUser(user);
	}
}
