package in.edac.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * CRUD
 * createUser
 * @author Mayuri
 *
 */
public class StepByStepDao {
	public static final String DB_DRIVER ="com.mysql.cj.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost:3306/edac";
	public static final String DB_USER = "root";
	public static final String DB_PASSWORD ="edac20";
	
	public void checkConnectionOld() {
		try {
			Class.forName(DB_DRIVER);
			
		Connection con 	= DriverManager.getConnection(DB_URL,DB_USER, DB_PASSWORD);
			// Explicityly close connection
		con.close();
		System.out.println("Success!!");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	// try with resource there is no need of finally below method
	public void checkConnection() {
		try(Connection con 	= DriverManager.getConnection(DB_URL,DB_USER, DB_PASSWORD);
				) {
			Class.forName(DB_DRIVER);
			
		
		
			System.out.println("Success Try with Resourse");
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	
	public boolean createUserV1() {
		try(Connection con	= DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
				) {
			Class.forName(DB_DRIVER);
			
		String sql = "INSERT INTO user(USERNAME, EMAIL, PASSWORD, MOBILE) VALUES (?, ?, ?, ?)";
		 PreparedStatement ps= con.prepareStatement(sql);
		 ps.setString(1,"Jiya");
		 ps.setString(2,"Jiya@gmail.com");
		 ps.setString(3,"Jiya123");
		 ps.setString(4,"1223456");
		 
		 ps.executeUpdate();
		 System.out.println("Insert Sucess");
		 
		 return true;
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	}
	
	
	public boolean createUserV2(String USERNAME, String EMAIL, String PASSWORD, String MOBILE) {
		try(Connection con	= DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
				) {
			Class.forName(DB_DRIVER);
			
		String sql = "INSERT INTO user(USERNAME, EMAIL, PASSWORD, MOBILE) VALUES (?, ?, ?, ?)";
		 PreparedStatement ps= con.prepareStatement(sql);
		 ps.setString(1,USERNAME);
		 ps.setString(2,EMAIL);
		 ps.setString(3,PASSWORD);
		 ps.setString(4,MOBILE);
		 
		 ps.executeUpdate();
		 System.out.println("Insert Sucess");
		 
		 return true;
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	}
	
	
	
	
	//by creating object of user in User.java for 100no of para
	public boolean createUser(User user) {
		try(Connection con	= DriverManager.getConnection(DB_URL,DB_USER,DB_PASSWORD);
				) {
			Class.forName(DB_DRIVER);
			
		String sql = "INSERT INTO user(USERNAME, EMAIL, PASSWORD, MOBILE) VALUES (?, ?, ?, ?)";
		 PreparedStatement ps= con.prepareStatement(sql);
		 ps.setString(1,user.getUsername());
		 ps.setString(2,user.getEmail());
		 ps.setString(3,user.getPassword());
		 ps.setString(4,user.getMobile());
		 
		 ps.executeUpdate();
		 System.out.println("Insert Sucess");
		 
		 return true;
		} catch (Exception e) {
			
			e.printStackTrace();
			return false;
		}
	}
	
	
	public static void main(String[] args) {
		StepByStepDao dao = new StepByStepDao();
		
		//check connection 
		//dao.checkConnectionOld();
		//dao.checkConnection();
		//dao.createUserV1();
		//dao.createUserV2("abcd", "abc@gmail.com", "abc123", "123344566");
		
		User user = new User("Mumbai","a1@gmail.com","12345","9887766545");
		dao.createUser(user);
	}
}
